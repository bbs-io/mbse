#ifndef	_NEWSPOST_H
#define	_NEWSPOST_H


int	newspost(void);


#endif

