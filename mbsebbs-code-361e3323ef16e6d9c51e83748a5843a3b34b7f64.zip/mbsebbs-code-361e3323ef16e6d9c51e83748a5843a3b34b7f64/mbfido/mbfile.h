/* $Id: mbfile.h,v 1.3 2001/11/18 23:19:08 mbroek Exp $ */

#ifndef _MBFILE_H_
#define _MBFILE_H


#endif
