#ifndef	_PTIC_H
#define	_PTIC_H

/* $Id: ptic.h,v 1.4 2005/11/12 12:52:30 mbse Exp $ */

int ProcessTic(fa_list **, orphans **);

#endif
