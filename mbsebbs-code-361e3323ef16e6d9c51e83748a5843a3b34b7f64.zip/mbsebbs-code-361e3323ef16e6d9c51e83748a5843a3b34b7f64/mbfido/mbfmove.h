/* $Id: mbfmove.h,v 1.1 2001/12/02 19:17:14 mbroek Exp $ */

#ifndef _MBFMOVE_H
#define _MBFMOVE_H

void Move(int, int, char *);

#endif
