#ifndef	_TOBEREP_H
#define	_TOBEREP_H

/* $Id: toberep.h,v 1.3 2004/03/11 18:58:52 mbroek Exp $ */

int Add_ToBeRep(struct _filerecord);

#endif
