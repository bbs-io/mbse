#ifndef _POSTNETMAIL_H
#define _POSTNETMAIL_H

/* $Id: postnetmail.h,v 1.2 2002/12/22 14:41:34 mbroek Exp $ */

int	postnetmail(FILE *, faddr *, faddr *, char *, char *, time_t, int, int, unsigned int, unsigned int);

#endif
