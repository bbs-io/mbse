/* $Id: mbflist.h,v 1.2 2001/11/25 14:13:55 mbroek Exp $ */

#ifndef _MBFLIST_H_
#define _MBFLIST_H

void	ListFileAreas(int);		/* List fileareas		*/

#endif
