#ifndef HASH_H
#define HASH_H

/* $Id: hash.h,v 1.2 2005/10/11 20:49:47 mbse Exp $ */

void hash_update_s(unsigned int *, char *);
void hash_update_n(unsigned int *, unsigned int);

#endif
