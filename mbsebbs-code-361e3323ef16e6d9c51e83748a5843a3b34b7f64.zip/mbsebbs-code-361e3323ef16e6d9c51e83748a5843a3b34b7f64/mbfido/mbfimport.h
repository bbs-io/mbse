/* $Id: mbfimport.h,v 1.1 2001/11/25 12:25:59 mbroek Exp $ */

#ifndef _MBFIMPORT_H
#define	_MBFIMPORT_H


void ImportFiles(int);

#endif

