#ifndef	_STOREECHO_H
#define	_STOREECHO_H

int storeecho(faddr *, faddr *, time_t, int, char *, char *, char *, int, int, FILE *);

#endif

