#ifndef _UNPACK_H
#define _UNPACK_H

/* $Id: unpack.h,v 1.1 2002/08/05 13:30:44 mbroek Exp $ */

int	checkspace(char *, char *, int);
int	unpack(char *);

#endif
