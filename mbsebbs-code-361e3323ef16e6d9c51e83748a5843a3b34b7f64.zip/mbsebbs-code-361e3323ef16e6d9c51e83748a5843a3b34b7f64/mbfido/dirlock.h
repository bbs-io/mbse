#ifndef _DIRLOCK_H
#define _DIRLOCK_H

int	lockdir(char *);
void	ulockdir(char *);

#endif
