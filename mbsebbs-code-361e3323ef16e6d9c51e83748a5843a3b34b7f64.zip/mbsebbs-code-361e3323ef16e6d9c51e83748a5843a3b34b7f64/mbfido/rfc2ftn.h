#ifndef	_RFC2FTN_H
#define	_RFC2FTN_H

/* $Id: rfc2ftn.h,v 1.2 2005/08/14 12:50:19 mbse Exp $ */

int charwrite(char *, FILE *);
int rfc2ftn(FILE *fp, faddr *);

#endif

