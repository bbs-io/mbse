#ifndef _MBAFF_H_
#define _MBAFF_H


int	Announce(void);			/* Announce files		   */


#endif

