#ifndef	_FORWARD_H
#define	_FORWARD_H


void ForwardFile(fidoaddr, fa_list *);


#endif

