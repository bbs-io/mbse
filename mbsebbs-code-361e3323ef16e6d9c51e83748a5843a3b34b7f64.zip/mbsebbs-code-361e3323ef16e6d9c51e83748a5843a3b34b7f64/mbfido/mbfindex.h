/* $Id: mbfindex.h,v 1.1 2001/11/18 23:19:08 mbroek Exp $ */

#ifndef _MBFINDEX_H_
#define _MBFINDEX_H

void	Index(void);			/* Index filerquest		*/

#endif
