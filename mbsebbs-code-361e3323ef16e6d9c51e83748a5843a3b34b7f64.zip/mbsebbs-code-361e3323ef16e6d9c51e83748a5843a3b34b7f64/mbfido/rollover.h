#ifndef	_ROLLOVER_H
#define	_ROLLOVER_H

/* $Id: rollover.h,v 1.2 2005/10/11 20:49:47 mbse Exp $ */

void StatAdd(statcnt *, unsigned int);
void Rollover(void);

#endif
