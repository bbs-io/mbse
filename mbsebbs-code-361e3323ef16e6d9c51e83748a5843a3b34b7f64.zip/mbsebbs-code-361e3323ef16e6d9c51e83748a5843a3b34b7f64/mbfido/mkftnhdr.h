#ifndef _MKFTNHDR_H
#define	_MKFTNHDR_H


int ftnmsgid(char *,char **,unsigned int *,char *);
ftnmsg *mkftnhdr(rfcmsg *, int, faddr *);


#endif

