#ifndef	_NOTIFY_H
#define	_NOTIFY_H


int Notify(char *);


#endif

