#ifndef	_SCAN_H
#define	_SCAN_H

/* $Id: scan.h,v 1.2 2005/10/11 20:49:47 mbse Exp $ */

void ScanMail(int);
int  RescanOne(faddr *, char *, unsigned int);

#endif
