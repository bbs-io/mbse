#ifndef	_ALIASDB_H
#define	_ALIASDB_H


#define MAXNAME 35

int	registrate(char *, char *);
char	*lookup(char *);


#endif

