/* $Id: createf.h,v 1.2 2002/04/18 19:39:23 mbroek Exp $ */

#ifndef	_CREATEH_H
#define	_CREATEH_H


int create_ticarea(char *, faddr *);
int CheckTicGroup(char *, int, faddr *);


#endif

