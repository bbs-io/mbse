#ifndef _TOSSPKT_H
#define _TOSSPKT_H


int	TossPkt(char *);
int	getmessage(FILE *, faddr *, faddr *);

#endif

