#ifndef	_OPENPORT_H
#define	_OPENPORT_H

/* $Id: openport.h,v 1.3 2004/06/20 14:38:11 mbse Exp $ */

int 	rawport(void);
int 	cookedport(void);

#endif
