#ifndef	_ATOUL_H
#define	_ATOUL_H

/* $Id: atoul.h,v 1.3 2005/10/11 20:49:47 mbse Exp $ */

#ifndef	USE_NEWSGATE

unsigned int atoul(char*);

#endif

#endif
