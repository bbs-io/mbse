/* mbsebbs.h */

#ifndef _MBSEBBS_H
#define _MBSEBBS_H

#define ReleaseDate __DATE__


#endif

