/* $Id: mbnewusr.h,v 1.1 2001/11/10 17:14:16 mbroek Exp $ */

#ifndef _MBNEWUSR_H
#define _MBNEWUSR_H

#define ReleaseDate __DATE__


#endif

