#ifndef _MENU_H
#define _MENU_H

void InitMenu(void);
void menu(void);
void DoMenu(int);
void DisplayMenu(void);

#endif

