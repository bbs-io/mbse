#ifndef _WAZOO_H
#define _WAZOO_H

int rxwazoo(void);
int txwazoo(void);

#endif

