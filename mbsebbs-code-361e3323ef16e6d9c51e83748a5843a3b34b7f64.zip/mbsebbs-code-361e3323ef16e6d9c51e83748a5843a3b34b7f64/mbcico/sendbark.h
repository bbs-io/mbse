#ifndef	_SENDBARK_H
#define	_SENDBARK_H

int sendbark(void);

#endif

