#ifndef	_TCPPROTO_H
#define	_TCPPROTO_H

int tcpsndfiles(file_list *);
int tcprcvfiles(void);


#endif

