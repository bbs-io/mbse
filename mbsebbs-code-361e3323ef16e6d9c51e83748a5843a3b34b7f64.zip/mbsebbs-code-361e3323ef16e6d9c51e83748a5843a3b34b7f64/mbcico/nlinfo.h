#ifndef	_NLINFO_H
#define	_NLINFO_H


int nlinfo(faddr *);


#endif

