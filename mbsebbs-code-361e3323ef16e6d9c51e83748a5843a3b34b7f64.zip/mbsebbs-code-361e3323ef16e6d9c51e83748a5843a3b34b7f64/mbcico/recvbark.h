#ifndef	_RECVBARK_H
#define	_RECVBARK_H

int recvbark(void);

#endif

