#ifndef	_FTSC_H
#define	_FTSC_H


int  rx_ftsc(void);
int  tx_ftsc(void);


#endif

