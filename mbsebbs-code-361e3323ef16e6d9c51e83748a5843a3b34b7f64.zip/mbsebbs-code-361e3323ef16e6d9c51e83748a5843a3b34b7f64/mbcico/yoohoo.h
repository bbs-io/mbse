#ifndef	_YOOHOO_H
#define	_YOOHOO_H

int rx_yoohoo(void);
int tx_yoohoo(void);

#endif

