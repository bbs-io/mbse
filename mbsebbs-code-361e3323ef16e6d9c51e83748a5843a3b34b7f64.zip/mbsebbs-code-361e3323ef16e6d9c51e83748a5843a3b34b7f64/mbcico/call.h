#ifndef	_CALL_H
#define	_CALL_H


int	call(faddr *);


#endif


