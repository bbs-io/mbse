#ifndef _DIRLOCK_H
#define _DIRLOCK_H

/* $Id: dirlock.h,v 1.1 2005/09/12 13:47:09 mbse Exp $ */

int	lockdir(char *);
void	ulockdir(char *);

#endif
