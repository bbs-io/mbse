#ifndef	_ANSWER_H
#define	_ANSWER_H

int answer(char *);


#endif

