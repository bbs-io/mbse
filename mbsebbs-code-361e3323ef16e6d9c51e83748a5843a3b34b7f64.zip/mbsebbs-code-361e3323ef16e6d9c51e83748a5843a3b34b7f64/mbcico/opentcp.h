/* $Id: opentcp.h,v 1.6 2004/02/01 14:38:49 mbroek Exp $ */

#ifndef	_OPENTCP_H
#define	_OPENTCP_H


int  opentcp(char *);
void closetcp(void);

#endif
