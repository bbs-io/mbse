#ifndef _EMSIDAT_H
#define	_EMSIDAT_H


char *mkemsidat(int);
int  scanemsidat(char *);


#endif

