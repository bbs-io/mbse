#ifndef _ULOCK_H
#define _ULOCK_H

int lock(char *);
int ulock(char *);

#endif

